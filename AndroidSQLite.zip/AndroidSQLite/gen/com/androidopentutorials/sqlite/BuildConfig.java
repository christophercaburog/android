/** Automatically generated file. DO NOT MODIFY */
package com.androidopentutorials.sqlite;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}